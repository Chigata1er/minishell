/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thitran <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/20 09:08:49 by thitran           #+#    #+#             */
/*   Updated: 2025/03/20 09:09:10 by thitran          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "minishell.h"
#include "libft/libft.h"
#include <readline/readline.h>
#include <readline/history.h>
#include <signal.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

void shell_loop(char **env)
{
    t_shell shell;
    init_shell(&shell, env);
    signal(SIGINT, signal_handler);  // Handle Ctrl+C
    signal(SIGQUIT, signal_handler); // Handle Ctrl+slash

    while (1)
    {
        dup2(shell.saved_stdout, STDOUT_FILENO);
        
        // Only print prompt if input comes from terminal
        if (isatty(STDIN_FILENO))
            shell.input = readline("minishell$ ");
        else
            shell.input = readline(NULL); // Don't print prompt in non-interactive mode

        if (!shell.input)
        {
            if (isatty(STDIN_FILENO)) // Only print "exit" when running interactively
                printf("exit\n");
            break;
        }

        if (strlen(shell.input) > 0)
        {
            add_history(shell.input);
            shell.args = ft_split_quotes(shell.input);

            expand_env_variables(&shell);
            parse_quotes(&shell);
            execute_command(&shell);
        }

        free_shell(&shell);
    }
}

int main(int argc, char **argv, char **env)
{
    (void)argc;
    (void)argv;
    shell_loop(env);
    return 0;
}
