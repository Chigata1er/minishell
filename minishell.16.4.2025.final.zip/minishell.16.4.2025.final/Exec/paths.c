/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   paths.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thitran <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/20 09:11:05 by thitran           #+#    #+#             */
/*   Updated: 2025/04/03 10:07:06 by thitran          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "../Header/Execution.h"
#include "../libft/libft.h"

int	check_if_path(char	*cmd)
{
	int	i;

	i = 0;
	if (!cmd)
		return (0);
	while (cmd[i])
	{
		if (cmd[i] == '/')
			return (1);
		i++;
	}
	return (0);
}

void	exec_path(t_cmd_table *cmd, char **execenv, char *path, char *env_path)
{
	if (cmd->cmd_table[0] && check_if_path(cmd->cmd_table[0]))
	{
		if (execve(path, cmd->cmd_table, execenv) == -1)
		{
			perror (cmd->cmd_table[0]);
			exit(127);
		}
	}
	else
	{
		if (check_if_path(cmd->cmd_table[0]))
			path = ft_strdup(cmd->cmd_table[0]);
		else
		{
			path = ft_strjoin(env_path, "/");
			path = ft_strjoin(path, cmd->cmd_table[0]);
		}
		if (!access(path, X_OK))
			execve(path, cmd->cmd_table, execenv);
		free(path);
	}
}

void	display_error(t_cmd_table *cmd)
{
	write(STDERR_FILENO, cmd->cmd_table[0], ft_strlen(cmd->cmd_table[0]));
	write(STDERR_FILENO, ": command not found\n", 20);
}

void	find_cmd(t_my_env *env, t_cmd_table *cmd)
{
	int		i;
	char	**paths;
	char	*path;
	char	**execenv;

	i = 0;
	if (builtin_recognizer(&cmd, cmd->cmd_table, &env))
		exit (status_setter(0, 0));
	env = env->next;
	paths = dup_func(env);
	path = ft_strdup(cmd->cmd_table[0]);
	while (cmd->cmd_table[0] && paths && paths[i])
	{
		execenv = listconvertion(env);
		exec_path(cmd, execenv, path, paths[i]);
		free_execenv(execenv);
		i++;
	}
	if (cmd->cmd_table[0] && !check_if_path(cmd->cmd_table[0]))
		display_error(cmd);
	if (cmd->cmd_table[0] == NULL)
		exit (0);
	exit (127);
}
