/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   exportaddmember_mode.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thitran <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/20 09:11:05 by thitran           #+#    #+#             */
/*   Updated: 2025/04/03 10:02:56 by thitran          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "../Header/Parsing.h"

void	addenvmember(t_export e, t_my_env **env)
{
	if (e.elem_value)
		add_member(env, creatdup(e.elem_name, e.elem_value));
	else
		add_member(env, creatdup(e.elem_name, NULL));
}
