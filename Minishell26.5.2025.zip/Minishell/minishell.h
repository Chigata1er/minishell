/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thitran <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/20 09:07:51 by thitran           #+#    #+#             */
/*   Updated: 2025/03/20 09:08:31 by thitran          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef MINISHELL_H
# define MINISHELL_H

# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <fcntl.h>
# include <signal.h>
# include <string.h>
# include <sys/wait.h>
# include <sys/types.h>
# include <sys/stat.h>
# include <dirent.h>
# include <errno.h>
# include <readline/readline.h>
# include <readline/history.h>

# define MAX_ARGS 1024
# define MAX_COMMANDS 100
// Structure for shell state
typedef struct s_shell {
    char    *input;
    char    **args; // Correct this line
    char    **env;
    int     last_exit_status;
    char    *input_file;
    char    *output_file;
    int     append_mode;
    int     pipe_count;
    int	    saved_stdin;
    int	    saved_stdout;
} t_shell;

void    init_shell(t_shell *shell, char **env);

void    parse_input(t_shell *shell);
void    expand_variables(t_shell *shell);
char    **split_pipes(char *input); // Function to split pipes
void 	expand_env_variables(t_shell *shell);
void 	parse_quotes(t_shell *shell);
void 	handle_redirection(t_shell *shell);
void 	free_shell(t_shell *shell);


void	execute_command(t_shell *shell);
void execute_pipeline(char *commands[MAX_COMMANDS], int cmd_count);
int 	is_builtin(char *cmd);
void    signal_handler(int sig);
void	ft_free_tab(char **tab);
char	*get_path_env(char **envp);
char	*check_command_in_paths(char **paths, char *cmd);
char	*find_command_path(char *cmd, char **envp);
void pipex(int infile, int outfile, char **cmds, char **envp, int cmd_count);
char **ft_split_quotes(char *input);

int     ft_echo(char **args);
int 	ft_cd(t_shell *shell, char **args);
int     ft_pwd(void);
int     ft_export(t_shell *shell, char **args);
int 	ft_unset(t_shell *shell, char **args);
int 	ft_env(char **env);
int     ft_exit(char **args);

void    signal_handler(int sig);

#endif

