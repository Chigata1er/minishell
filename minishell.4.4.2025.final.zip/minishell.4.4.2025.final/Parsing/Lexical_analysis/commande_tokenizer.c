/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   commande_tokenizer.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thitran <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/20 09:11:05 by thitran           #+#    #+#             */
/*   Updated: 2025/04/03 10:22:56 by thitran          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "../../Header/Parsing.h"

int	quoted_symbole(char c)
{
	return (c == '|' || c == '<' || c == '>' || c == '$' || c == '"'
		|| c == '\'' || c == ' ' || c == '\n' || c == '\t' || c == '~');
}

char	*get_t_word_token(char *commande, t_token_list **token,
		enum e_token_type t_type, enum e_token_state s_token)
{
	int	j;

	j = 0;
	while (commande[j] && !quoted_symbole(commande[j]))
		j++;
	add_tokens_to_list(token, build_new_token_node(ft_strndup(commande, j),
			t_type, s_token));
	return (commande + j);
}

char	*get_space_token(char *commande, t_token_list **token,
		enum e_token_type t_type, enum e_token_state s_token)
{
	add_tokens_to_list(token, build_new_token_node(ft_strndup(commande, 1),
			t_type, s_token));
	return (commande + 1);
}

char	*get_pipe_token(char *commande, t_token_list **token,
		enum e_token_type t_type, enum e_token_state s_token)
{
	add_tokens_to_list(token, build_new_token_node(ft_strndup(commande, 1),
			t_type, s_token));
	return (commande + 1);
}

/*HERE WE GET TOKEN LINKED LIST*/
char	*lexems_finder(char *commande, t_token_list **token)
{
	if (!quoted_symbole(*commande))
		commande = get_t_word_token(commande, token, WORD, NORMAL);
	else if (*commande == ' ')
		commande = get_space_token(commande, token, A_SPACE, NORMAL);
	else if (*commande == '|')
		commande = get_pipe_token(commande, token, PIPE, NORMAL);
	else if (*commande == '\'')
		commande = single_quote_content(commande, token, WORD, IN_SQUOT);
	else if (*commande == '\"')
		commande = double_quote_content(commande, token, WORD, IN_DQUOT);
	else if (*commande == '>')
		commande = get_out_redir_token(commande, token, OUT_REDIR, NORMAL);
	else if (*commande == '<')
		commande = get_in_redir_token(commande, token, IN_REDIR, NORMAL);
	else if (*commande == '$')
		commande = dollar_geter(commande, token, ENV_VAR, NORMAL);
	else if (*commande == '~')
		commande = home_geter(commande, token, ENV_VAR, NORMAL);
	return (commande);
}
