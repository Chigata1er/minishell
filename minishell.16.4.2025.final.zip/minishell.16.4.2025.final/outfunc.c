/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   outfunc.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thitran <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/20 09:11:05 by thitran           #+#    #+#             */
/*   Updated: 2025/04/03 09:59:59 by thitran          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "./Header/Parsing.h"
#include "./Header/Execution.h"
#include "./libft/libft.h"

void	history_acces(char *commande)
{
	int		state;
	size_t	i;

	i = 0;
	white_space(commande, i, ft_strlen(commande), &state);
	if (state)
		add_history(commande);
}

void	clean_memory(t_token_list **token)
{
	free_token_list(token);
}

/*mode = 1 mean we sett the value*/
int	status_setter(int code, int mode)
{
	static int	exit_status;

	if (mode)
		exit_status = code;
	return (exit_status);
}

void	free_cmd_table(t_cmd_table **cmd)
{
	t_cmd_table	*tmp;
	int			i;

	if (!cmd)
		return ;
	while (*cmd)
	{
		tmp = *cmd;
		*cmd = (*cmd)->next;
		i = 0;
		while (tmp->cmd_table[i])
		{
			free(tmp->cmd_table[i]);
			i++;
		}
		free(tmp->cmd_table);
		free(tmp);
	}
	*cmd = NULL;
}

void	unlink_heredoc(void)
{
	int		index;
	char	*filename;
	char	*forward;
	char	*tmp;

	filename = NULL;
	index = 1;
	while (1)
	{
		forward = ft_itoa(index);
		tmp = ft_strdup("/tmp/.her_talb");
		filename = ft_strjoin(tmp, forward);
		free(tmp);
		if (unlink(filename) == -1)
		{
			free(filename);
			free(forward);
			break ;
		}
		free(forward);
		free(filename);
		index++;
	}
}
