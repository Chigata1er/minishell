/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Execution.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thitran <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/20 09:11:05 by thitran           #+#    #+#             */
/*   Updated: 2025/04/03 10:09:06 by thitran          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef EXECUTION_H
# define EXECUTION_H

# include "Parsing.h"
# include <dirent.h>
# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <sys/stat.h>
# include <readline/readline.h>
# include <readline/history.h>

typedef struct l_cmd	t_cmd_table;
typedef struct v_envp	t_my_env;

typedef struct s_env
{
	char			*key_env;	
	char			*value_env;
	int				show_option;
	struct s_env	*next;
	char			**paths;
}		t_env;

void	dir(char *cmd);
void	dupin(t_cmd_table *cmd);
int		check_if_path(char	*cmd);
char	**dup_func(t_my_env *env);
char	**free_execenv(char **execenv);
char	**listconvertion(t_my_env *env);
void	ft_putstr_fd(char *str, int fd);
void	find_cmd(t_my_env *env, t_cmd_table *cmd);
int		my_pipes(t_cmd_table *cmd, t_my_env *new_env);
void	copy_str(char *s1, char **key, char **value);
void	execution(t_cmd_table	*cmd, t_my_env	*env);
void	str_length(char *s1, int *key_length, int *value_length);
void	child_exec(t_cmd_table *cmd, t_my_env *new_env, int pipe[2]);
void	p_exec(int pid, t_cmd_table *cmd, t_my_env *new_env, int pipe[2]);
char	*epur_string(char *str);
void	history_acces(char *commande);
void	white_space(char *str, size_t i, size_t len, int *state);
int		ft_isspace(int c);

#endif
