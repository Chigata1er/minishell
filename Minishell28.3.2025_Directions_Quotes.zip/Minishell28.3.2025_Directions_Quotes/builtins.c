/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   builtins.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thitran <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/20 09:11:05 by thitran           #+#    #+#             */
/*   Updated: 2025/03/20 09:11:31 by thitran          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "minishell.h"
#include "libft/libft.h"
#include <stdlib.h>
#include <stdio.h>

void add_env(char ***env, const char *new_var)
{
    int count = 0;

    // Count the number of existing environment variables
    while ((*env)[count])
        count++;

    // Reallocate memory for the new environment list (one more entry)
    char **new_env = malloc((count + 2) * sizeof(char *));  // +1 for the new variable and +1 for NULL
    if (!new_env)
    {
        perror("malloc");
        return;
    }

    // Copy the existing environment variables into the new array
    for (int i = 0; i < count; i++)
        new_env[i] = (*env)[i];

    // Allocate memory for the new variable
    new_env[count] = malloc(ft_strlen(new_var) + 1);  // Allocate space for the variable string
    if (!new_env[count])
    {
        perror("malloc");
        free(new_env);
        return;
    }

    // Manually copy the string using printf-like logic
    char *ptr = new_env[count];
    while (*new_var)
    {
        *ptr++ = *new_var++;
    }
    *ptr = '\0';  // Null-terminate the string

    new_env[count + 1] = NULL;  // NULL-terminate the array

    free(*env);  // Free the old environment array
    *env = new_env;  // Update the shell's environment to point to the new array
}

int ft_export(t_shell *shell, char **args)
{
    if (!shell || !shell->env)
        return 1;

    if (!args[1])  // No arguments: print all environment variables
    {
        for (int i = 0; shell->env[i]; i++)
            printf("declare -x %s\n", shell->env[i]);
        return 0;
    }

    for (int i = 1; args[i]; i++)
    {
        char *equal = ft_strchr(args[i], '=');
        if (!equal)  // If there's no '=', just add an empty value
        {
            size_t len = ft_strlen(args[i]) + 2;  // +1 for '=' and +1 for NULL
            char *new_var = malloc(len);
            if (!new_var)
                return 1;

            // Manually copy the string using printf
            char *ptr = new_var;
            while (*args[i])
            {
                *ptr++ = *args[i]++;
            }
            *ptr++ = '=';  // Add the equal sign
            *ptr = '\0';    // Null-terminate the string

            add_env(&shell->env, new_var);  // Add to shell environment
            free(new_var);
        }
        else  // If '=' exists, split key and value
        {
            *equal = '\0';  // Temporarily split key and value
            size_t len = ft_strlen(args[i]) + ft_strlen(equal + 1) + 2;  // +1 for '=' and +1 for NULL
            char *new_var = malloc(len);
            if (!new_var)
                return 1;

            // Manually copy the key part
            char *ptr = new_var;
            while (*args[i])
            {
                *ptr++ = *args[i]++;
            }
            *ptr++ = '=';  // Add the equal sign

            // Manually copy the value part
            equal++;  // Increment the pointer to skip the '='
            while (*equal)
            {
                *ptr++ = *equal++;
            }
            *ptr = '\0';    // Null-terminate the string

            add_env(&shell->env, new_var);  // Add to shell environment
            free(new_var);

            *equal = '=';  // Restore original string
        }
    }
    return 0;
}

int ft_unset(t_shell *shell, char **args)
{
    if (!shell || !shell->env || !args[1])  // No arguments: unset should print nothing and return
        return 0;

    for (int i = 1; args[i]; i++)
    {
        int j = 0;
        while (shell->env[j])
        {
            if (ft_strncmp(shell->env[j], args[i], ft_strlen(args[i])) == 0 &&
                shell->env[j][strlen(args[i])] == '=')
            {
                free(shell->env[j]);  // Free environment variable

                // Shift remaining variables
                for (int k = j; shell->env[k]; k++)
                    shell->env[k] = shell->env[k + 1];

                break;  // Only remove the first match
            }
            j++;
        }
    }
    return 0;
}


int ft_echo(char **args)
{
    int i = 1;
    int newline = 1;

    // Check for -n flag
    if (args[1] && ft_strcmp(args[1], "-n") == 0)
    {
        newline = 0;
        i++;
    }

    while (args[i])
    {
        write(1, args[i], ft_strlen(args[i]));
        if (args[i + 1])
            write(1, " ", 1);
        i++;
    }

    if (newline)
        write(1, "\n", 1);
    
    return 0;
}

// Change directory built-in command
int ft_cd(t_shell *shell, char **args)
{
    (void)shell;  // Suppress unused parameter warning for 'shell'
    // If 'args' is valid and contains a directory path, change directory
    if (args && args[1]) {
        if (chdir(args[1]) == -1) {
            perror("cd");
            return 1;  // Return non-zero for error
        }
    } else {
        // Handle the case where no arguments are passed to 'cd' (default to HOME)
        if (chdir(getenv("HOME")) == -1) {
            perror("cd");
            return 1;
        }
    }
    return 0;  // Success
}

// Print working directory built-in command
int ft_pwd(void)
{
    char cwd[1024];
    if (getcwd(cwd, sizeof(cwd)) != NULL) {
        printf("%s\n", cwd);
    } else {
        perror("pwd");
        return 1;
    }
    return 0;  // Success
}

// Environment built-in command
int ft_env(char **env)
{
    (void)env;  // Suppress unused parameter warning for 'env'
    // Print environment variables
    for (int i = 0; env[i]; i++) {
        printf("%s\n", env[i]);
    }
    return 0;  // Success
}

// Exit built-in command
int ft_exit(char **args)
{
    if (args && args[1]) {
        int exit_code = ft_atoi(args[1]);
        exit(exit_code);
    }
    exit(0);  // Default exit code 0
}
int is_builtin(char *cmd)
{
    if (!cmd)
        return (0);
    if (ft_strcmp(cmd, "echo") == 0 || ft_strcmp(cmd, "cd") == 0 ||
        ft_strcmp(cmd, "pwd") == 0 || ft_strcmp(cmd, "export") == 0 ||
        ft_strcmp(cmd, "unset") == 0 || ft_strcmp(cmd, "env") == 0 ||
        ft_strcmp(cmd, "exit") == 0)
        return (1);
    return (0);
}


