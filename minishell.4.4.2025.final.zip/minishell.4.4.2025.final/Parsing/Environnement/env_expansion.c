/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   env_expansion.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thitran <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/20 09:11:05 by thitran           #+#    #+#             */
/*   Updated: 2025/04/03 10:16:09 by thitran          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "../../Header/Parsing.h"
#include "../../libft/libft.h"

int	ft_strcmp(char *s1, char *s2)
{
	int	i;

	i = 0;
	if (!s1 || !s2)
		return (404);
	while (s1 && s2 && s1[i] && s2[i] && s1[i] == s2[i])
		i++;
	return (s1[i] - s2[i]);
}

char	*replaceby_content(char *search_for, t_my_env **env)
{
	t_my_env	*cursus;

	cursus = (*env)->next;
	while (cursus)
	{
		if (!ft_strcmp(search_for + 1, cursus->var))
		{
			free(search_for);
			return (ft_strndup(cursus->var_content, \
					ft_strlen(cursus->var_content)));
		}
		cursus = cursus->next;
	}
	free(search_for);
	return (ft_strndup("", ft_strlen("")));
}

void	env_var_expansion(t_token_list **tokens, t_my_env **env)
{
	t_token_list	*cursur;
	t_token_list	*prev;

	cursur = (*tokens);
	while (cursur)
	{
		if (cursur->type == ENV_VAR || cursur->type == SPECIAL_VAR)
		{
			if (cursur->prev)
			{
				prev = behind_getter(cursur);
				if (prev->type == HERE_DOC)
				{
					cursur->type = WORD;
					cursur = cursur->next;
					continue ;
				}
			}
			cursur->token = replaceby_content(cursur->token, env);
			cursur->type = WORD;
		}
		cursur = cursur->next;
	}
}

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	char			*str;
	unsigned int	i;
	unsigned int	j;

	if (s)
	{
		i = start;
		j = 0;
		str = (char *)malloc(sizeof(char) * (len + 1));
		if (!str)
			return (NULL);
		while (s[i] && i < (len + start))
		{
			str[j++] = s[i++];
		}
		str[j] = '\0';
		return (str);
	}
	return (NULL);
}

void	free_env(t_my_env **env)
{
	t_my_env	*cursur;

	while (*env)
	{
		cursur = *env;
		(*env) = (*env)->next;
		free(cursur->var);
		free(cursur->var_content);
		free(cursur);
	}
}
