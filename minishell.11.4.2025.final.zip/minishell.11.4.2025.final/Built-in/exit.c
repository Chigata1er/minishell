/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   exit.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thitran <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/20 09:11:05 by thitran           #+#    #+#             */
/*   Updated: 2025/04/03 10:01:57 by thitran          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "../Header/Parsing.h"
#include "../libft/libft.h"

unsigned char	to_uns(unsigned char c)
{
	status_setter(c, 1);
	return (c);
}

int	integer(char *integer)
{
	int	i;

	i = 0;
	if (integer[i] == '-' || integer[i] == '+')
		i++;
	while (integer[i])
	{
		if (integer[i] < '0' || integer[i] > '9')
			return (0);
		i++;
	}
	return (1);
}

void	clean_area(t_cmd_table **head, t_my_env **env, int status)
{
	free_env(env);
	free_cmd_table(head);
	status_setter(status, 1);
	exit(status);
}

int	run_exit(t_cmd_table **head, char **cmd_table, t_my_env **env)
{
	write(1, "exit\n", 5);
	if (!cmd_table[1])
		clean_area(head, env, 0);
	if (cmd_table[1] && cmd_table[2])
	{
		error_announcer("exit: too many arguments", 0);
		return (status_setter(1, 1));
	}
	if (cmd_table[1] && integer(cmd_table[1]))
		clean_area(head, env, to_uns(ft_atoi(cmd_table[1])));
	ft_putstr_fd("exit: ", 2);
	ft_putstr_fd(cmd_table[1], 2);
	ft_putendl_fd(": numeric argument required", 2);
	clean_area(head, env, 255);
	return (1);
}
