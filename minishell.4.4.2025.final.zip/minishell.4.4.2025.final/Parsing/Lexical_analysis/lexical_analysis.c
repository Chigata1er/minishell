/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   lexical_analysis.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thitran <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/20 09:11:05 by thitran           #+#    #+#             */
/*   Updated: 2025/04/03 10:23:30 by thitran          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "../../Header/Parsing.h"

t_token_list	*lexical_analysis(char *commande, t_my_env **env)
{
	t_token_list	*token;
	char			*begin;

	begin = commande;
	token = NULL;
	while (commande && *commande)
		commande = lexems_finder(commande, &token);
	env_var_expansion(&token, env);
	tokens_cleaner(&token);
	free(begin);
	return (token);
}
