#include <stdarg.h>
#include <unistd.h>
#include <stdlib.h>

static int ft_putchar(char c)
{
    return write(1, &c, 1);
}

static int ft_putstr(char *str)
{
    int len = 0;
    if (!str)
        str = "(null)";
    while (str[len])
        ft_putchar(str[len++]);
    return len;
}

static int ft_putnbr(int n)
{
    int len = 0;
    if (n == 0)
        return ft_putchar('0');
    if (n == -2147483648)
        return write(1, "-2147483648", 11);
    if (n < 0)
    {
        len += ft_putchar('-');
        n = -n;
    }
    if (n >= 10)
        len += ft_putnbr(n / 10);
    len += ft_putchar(n % 10 + '0');
    return len;
}

static int ft_putnbr_hex(unsigned int n, int uppercase)
{
    const char *hex_chars = uppercase ? "0123456789ABCDEF" : "0123456789abcdef";
    char buffer[9];
    int i = 8;
    int len = 0;

    if (n == 0)
        return ft_putchar('0');

    buffer[i--] = '\0';
    while (n > 0)
    {
        buffer[i--] = hex_chars[n % 16];
        n /= 16;
    }

    while (buffer[++i])
        len += ft_putchar(buffer[i]);
    
    return len;
}

int ft_printf(const char *format, ...)
{
    va_list args;
    int total_len = 0;

    va_start(args, format);
    while (*format)
    {
        if (*format == '%' && (*(format + 1) == 's' || *(format + 1) == 'd' || *(format + 1) == 'x'))
        {
            format++; // Skip the '%' character
            if (*format == 's')
                total_len += ft_putstr(va_arg(args, char *));
            else if (*format == 'd')
                total_len += ft_putnbr(va_arg(args, int));
            else if (*format == 'x')
                total_len += ft_putnbr_hex(va_arg(args, unsigned int), 0);
        }
        else
        {
            total_len += ft_putchar(*format);
        }
        format++;
    }
    va_end(args);
    return total_len;
}
