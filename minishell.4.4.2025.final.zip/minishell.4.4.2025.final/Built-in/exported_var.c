/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   exported_var.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thitran <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/20 09:11:05 by thitran           #+#    #+#             */
/*   Updated: 2025/04/03 10:03:27 by thitran          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "../Header/Parsing.h"
#include "../libft/libft.h"

t_my_env	*duplicate_env(t_my_env **original)
{
	t_my_env	*dup_head;
	t_my_env	*duped_node;
	t_my_env	*current;
	t_my_env	*previ;

	dup_head = NULL;
	previ = NULL;
	current = (*original)->next;
	while (current)
	{
		duped_node = creatdup(current->var, current->var_content);
		if (duped_node == NULL)
			return (NULL);
		if (!previ)
			dup_head = duped_node;
		else
			previ->next = duped_node;
		previ = duped_node;
		current = current->next;
	}
	return (dup_head);
}

t_my_env	*creatdup(char *var, char *var_content)
{
	t_my_env	*duped_node;

	duped_node = (t_my_env *)malloc(sizeof(t_my_env));
	if (duped_node == NULL)
		return (NULL);
	duped_node->var = ft_strdup(var);
	duped_node->var_content = ft_strdup(var_content);
	duped_node->m_env = NULL;
	duped_node->next = NULL;
	duped_node->prev = NULL;
	return (duped_node);
}

void	sorting(t_my_env *env)
{
	t_my_env	*circl;

	if (!env)
		return ;
	circl = env;
	while (circl->next)
	{
		if (ft_strcmp(circl->var, circl->next->var) > 0)
		{
			regulateur(circl, circl->next);
			circl = env;
		}
		else
			circl = circl->next;
	}
}

void	regulateur(t_my_env *curs, t_my_env *next)
{
	char	*t_key;
	char	*t_value;

	t_key = curs->var;
	curs->var = next->var;
	next->var = t_key;
	t_value = curs->var_content;
	curs->var_content = next->var_content;
	next->var_content = t_value;
}
