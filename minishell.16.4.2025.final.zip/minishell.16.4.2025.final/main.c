/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thitran <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/20 09:11:05 by thitran           #+#    #+#             */
/*   Updated: 2025/04/11 15:26:23 by thitran          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "./Header/Parsing.h"
#include "./Header/Execution.h"
#include "./libft/libft.h"

char	*epur_string(char *str)
{
	int		i;
	int		j;
	char	*cleaned;

	i = 0;
	j = 0;
	if (!str)
		return (NULL);
	while (str[i] && ft_isspace(str[i]))
		i++;
	cleaned = (char *)malloc(sizeof(char) * (ft_strlen(str) + 1));
	if (!cleaned)
		return (NULL);
	while (str[i])
	{
		if (!ft_isspace(str[i]) || (j > 0 && !ft_isspace(cleaned[j - 1])))
			cleaned[j++] = str[i];
		i++;
	}
	if (j > 0 && ft_isspace(cleaned[j - 1]))
		j--;
	cleaned[j] = '\0';
	return (cleaned);
}

void	seg_handler_c(int status)
{
	if (status == SIGINT && waitpid(-1, NULL, 0) == -1)
	{
		status_setter(1, 1);
		write(1, "\n", 1);
		rl_on_new_line();
		rl_replace_line("", 0);
		rl_redisplay();
	}
}

void	get_input_line(char **commande, t_my_env **my_env)
{
	char	*tmp;

	*commande = readline("minishell$ ");
	if (*commande == NULL)
	{
		status_setter(EXIT_SUCCESS, 1);
		rl_clear_history();
		clear_history();
		free_env(my_env);
		write(1, "exit\n", 5);
		exit(EXIT_SUCCESS);
	}
	tmp = *commande;
	*commande = epur_string(*commande);
	free(tmp);
	history_acces(*commande);
}

void	minishell(t_my_env *my_env)
{
	char			*readedline;
	t_token_list	*token;
	t_cmd_table		*cmd_tabl;

	readedline = NULL;
	while (1)
	{
		get_input_line(&readedline, &my_env);
		token = lexical_analysis(readedline, &my_env);
		if (syntax_analysis(token) == SUCCES_PROC)
		{
			cmd_tabl = parsing(&token, &my_env);
			execution(cmd_tabl, my_env);
			unlink_heredoc();
			free_cmd_table(&cmd_tabl);
		}
		else
		{
			status_setter(SYNTAXE_ERR_STATUS, 1);
			clean_memory(&token);
		}
		free(readedline);
		readedline = NULL;
	}
}

int	main(int ac, char **av, char **env)
{
	t_my_env	*my_env;

	(void)ac;
	(void)av;
	status_setter(0, 1);
	catche_signal();
	my_env = import_env(env);
	minishell(my_env);
	return (SUCCES_PROC);
}
