/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cleaner_end.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thitran <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/20 09:11:05 by thitran           #+#    #+#             */
/*   Updated: 2025/04/03 10:18:08 by thitran          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "../../Header/Parsing.h"
#include "../../libft/libft.h"

char	*assemble_data(t_token_list *begin, int end)
{
	char	*join;

	join = ft_strndup(begin->token, (int)ft_strlen(begin->token));
	while (begin->index < end)
	{
		join = ft_strjoin(join, begin->next->token);
		begin = begin->next;
	}
	return (join);
}

void	free_region(t_token_list **start, t_token_list **end)
{
	t_token_list	*current;
	t_token_list	*next;

	current = *start;
	while (current != NULL)
	{
		next = current->next;
		free(current->token);
		free(current);
		current = next;
		if (current == (*end))
		{
			free(current->token);
			free(current);
			break ;
		}
	}
}

void	specialcase_handler(t_token_list **tokens)
{
	t_token_list	*cursur;
	t_pos_get		*to_extract;

	cursur = (*tokens);
	while (cursur)
	{
		to_extract = index_range_getter(tokens);
		if (to_extract->start != to_extract->end)
		{
			addclean_token(tokens, to_extract->start, to_extract->end,
				data_assembler(tokens, to_extract));
			cursur = (*tokens);
		}
		cursur = cursur->next;
		free(to_extract);
	}
}
