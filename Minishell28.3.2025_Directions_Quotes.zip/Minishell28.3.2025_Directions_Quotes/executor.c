/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   executor.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thitran <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/20 09:10:22 by thitran           #+#    #+#             */
/*   Updated: 2025/03/20 09:10:47 by thitran          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include "libft/libft.h"
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <dirent.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <ctype.h>

void signal_handler(int sig)
{
    if (sig == SIGINT)
    {
        rl_on_new_line();
        rl_replace_line("     ", 0);
        rl_redisplay();
        write(1, "\nminishell$ ", 12);
    }
    else if (sig == SIGQUIT)
    {
        rl_on_new_line();
        rl_replace_line("     ", 0);
        rl_redisplay();
    }
}

void init_shell(t_shell *shell, char **env)
{
    shell->input = NULL;
    shell->args = NULL;
    shell->env = env;
    shell->last_exit_status = 0;
    shell->input_file = NULL;
    shell->output_file = NULL;
    shell->append_mode = 0;
    shell->pipe_count = 0;    
    shell->saved_stdin = dup(0);
    shell->saved_stdout = dup(1);
}

void free_shell(t_shell *shell)
{
    if (shell->input)
        free(shell->input);
    if (shell->args)
    {
        for (int i = 0; shell->args[i]; i++)
            free(shell->args[i]);
        free(shell->args);
    }
    if (shell->input_file)
        free(shell->input_file);
    if (shell->output_file)
        free(shell->output_file);
}

// Expand environment variables only when they are not inside single quotes
void expand_env_variables(t_shell *shell)
{
    for (int i = 0; shell->args[i]; i++)
    {
        char *arg = shell->args[i];
        int in_single_quote = 0, in_double_quote = 0;
        char new_arg[1024];  // Buffer for modified argument
        int j = 0, k = 0;

        while (arg[j])
        {
            // Toggle single quote mode (ignore expansion inside single quotes)
            if (arg[j] == '\'' && !in_double_quote)
                in_single_quote = !in_single_quote;
            // Toggle double quote mode (only allow expansion inside double quotes)
            else if (arg[j] == '"' && !in_single_quote)
                in_double_quote = !in_double_quote;
            // Handle expansion of environment variables only outside single quotes
            else if (arg[j] == '$' && !in_single_quote)
            {
                // Handle variable expansion only if we're not inside single quotes
                char var_name[256];
                int v = 0, start = j + 1;

                // Extract variable name
                while (arg[start] && (isalnum(arg[start]) || arg[start] == '_'))
                    var_name[v++] = arg[start++];
                var_name[v] = '\0';

                // Look for the environment variable value
                char *var_value = getenv(var_name);

                if (var_value)
                {
                    // Copy the value of the environment variable
                    ft_strcpy(&new_arg[k], var_value);
                    k += ft_strlen(var_value);
                }
                j = start - 1;  // Skip past the variable name
            }
            // Handle backslash escaping for special characters
            else if (arg[j] == '\\' && (in_single_quote || in_double_quote))
            {
                // Skip the next character as it's escaped
                j++;
            }
            // Preserve semicolons inside quotes
            else if (arg[j] == ';' && (in_single_quote || in_double_quote))
            {
                new_arg[k++] = arg[j];  // Copy semicolon inside quotes as regular character
            }
            else
            {
                new_arg[k++] = arg[j];  // Copy non-special characters
            }

            j++;
        }

        new_arg[k] = '\0';  // Null-terminate the new argument string

        free(shell->args[i]);
        shell->args[i] = ft_strdup(new_arg);  // Update the argument in the shell
    }
}

// Function to check if quotes are balanced
int is_balanced_quotes(const char *str)
{
    int single_quote = 0, double_quote = 0;
    while (*str)
    {
        if (*str == '\'' && double_quote == 0)
            single_quote = !single_quote;
        else if (*str == '"' && single_quote == 0)
            double_quote = !double_quote;
        str++;
    }
    return (single_quote == 0 && double_quote == 0);
}

// Function to parse and remove quotes (ignores unbalanced quotes)
void parse_quotes(t_shell *shell)
{
    int i = 0;
    while (shell->args[i])
    {
        char *arg = shell->args[i];
        int len = ft_strlen(arg);
        char *new_arg = malloc(len + 1);
        int j = 0, k = 0;
        int in_single_quote = 0, in_double_quote = 0;

        if (!new_arg)
            return;

        // Skip unbalanced quotes
        if (!is_balanced_quotes(arg)) 
        {
            free(new_arg);
            i++;
            continue;  // Ignore unbalanced quotes and skip to the next argument
        }

        // Parse the argument while ignoring quotes
        while (arg[j])
        {
            if (arg[j] == '\'' && !in_double_quote)
                in_single_quote = !in_single_quote;
            else if (arg[j] == '"' && !in_single_quote)
                in_double_quote = !in_double_quote;
            else
                new_arg[k++] = arg[j];  // Add character unless it's a quote or escape

            j++;
        }

        new_arg[k] = '\0';  // Null-terminate the new argument string

        free(shell->args[i]);
        shell->args[i] = ft_strdup(new_arg);  // Update the argument in the shell
        free(new_arg);
        i++;
    }
}

char **ft_split_quotes(char *input)
{
    int i = 0, j = 0, k = 0;
    char **result = malloc(sizeof(char*) * 10);  // Allocate space for 10 words
    char *word = malloc(ft_strlen(input) + 1);      // Temporary buffer for each word

    while (input[i]) {
        // Skip spaces
        if (ft_isspace(input[i])) {
            i++;
            continue;
        }

        // Handle quote-encapsulated words
        if (input[i] == '"' || input[i] == '\'') {
            char quote = input[i++];
            k = 0;
            while (input[i] != quote) {
                word[k++] = input[i++];
            }
            word[k] = '\0';  // Null-terminate the word
            i++;  // Skip the closing quote
        } else {
            // Handle normal words (not inside quotes)
            k = 0;
            while (input[i] && !ft_isspace(input[i]) && input[i] != '"' && input[i] != '\'') {
                word[k++] = input[i++];
            }
            word[k] = '\0';  // Null-terminate the word
        }

        result[j++] = strdup(word);
    }

    result[j] = NULL;  // Null-terminate the result array
    free(word);
    return result;
}

void handle_redirection(t_shell *shell)
{
    int i = 0;
    while (shell->args[i])
    {
        if (ft_strcmp(shell->args[i], ">") == 0) // Output redirection
        {
            int fd = open(shell->args[i + 1], O_CREAT | O_WRONLY | O_TRUNC, 0644);
            if (fd == -1)
            {
                perror("open");
            }
            else
            {
                dup2(fd, STDOUT_FILENO);  // Redirect stdout
                close(fd);
                shell->args[i] = NULL;    // Remove redirection part from args
                break; // Once redirection is handled, exit loop
            }
        }
        else if (ft_strcmp(shell->args[i], "<") == 0) // Input redirection
        {
            int fd = open(shell->args[i + 1], O_RDONLY);
            if (fd == -1)
            {
                perror("open");
            }
            else
            {
                dup2(fd, STDIN_FILENO);  // Redirect stdin
                close(fd);
                shell->args[i] = NULL;    // Remove redirection part from args
                break; // Once redirection is handled, exit loop
            }          
        }
	else if (ft_strcmp(shell->args[i], ">>") == 0) // Append mode
        {
            int fd = open(shell->args[i + 1], O_CREAT | O_WRONLY | O_APPEND, 0644);
            if (fd == -1)
            {
                perror("open");
            }
            else
            {            
                dup2(fd, STDOUT_FILENO);  // Redirect stdout in append mode
                close(fd);
                shell->args[i] = NULL;    // Remove redirection part from args
                break; // Once redirection is handled, exit loop
            }
        }
        else if (ft_strcmp(shell->args[i], "<<") == 0) // Here-document
        {
            char *delimiter = shell->args[i + 1];
            int pipefd[2];
            pipe(pipefd);

            char *line;
            while ((line = readline("> ")) != NULL)
            {
                // Remove trailing newline from line before comparison
                line[ft_strcspn(line, "\n")] = 0;

                // Compare the trimmed line with the delimiter
                if (ft_strcmp(line, delimiter) == 0)
                    break;  // Break when the delimiter is matched

                // Write the input line to the pipe
                write(pipefd[1], line, strlen(line));  
                write(pipefd[1], "\n", 1);  // Add newline after each line
                free(line);
            }

            close(pipefd[1]);  // Close the pipe's writing end
            dup2(pipefd[0], STDIN_FILENO);  // Redirect stdin from the pipe's reading end
            close(pipefd[0]);  // Close the pipe's reading end
            shell->args[i] = NULL;    // Remove here-doc part from args
            break; // Once here-document redirection is handled, exit loop
        }
        i++;        
    }
}

void handle_echo(t_shell *shell)
{
    int i = 1;

    while (shell->args[i])
    {
        char *arg = shell->args[i];
        int len = ft_strlen(arg);

        if (len > 1 && ((arg[0] == '"' && arg[len - 1] == '"') || 
                        (arg[0] == '\'' && arg[len - 1] == '\'')))
        {
            shell->args[i] = ft_strndup(arg + 1, len - 2); // Remove quotes
        }
        i++;
    }

    ft_echo(shell->args);  // Call ft_echo after handling quotes
}

void execute_command(t_shell *shell)
{
    if (!shell->args || !shell->args[0])
        return;

    // Handle builtins first
    if (ft_strcmp(shell->args[0], "exit") == 0)
        exit(0);
    else if (ft_strcmp(shell->args[0], "cd") == 0)
        ft_cd(shell, shell->args);
    else if (ft_strcmp(shell->args[0], "pwd") == 0)
        ft_pwd();
     else if (ft_strcmp(shell->args[0], "export") == 0)
        ft_export(shell, shell->args);
    else if (ft_strcmp(shell->args[0], "unset") == 0)
        ft_unset(shell, shell->args);
    else if (ft_strcmp(shell->args[0], "env") == 0)
        ft_env(shell->env);
    else if (ft_strcmp(shell->args[0], "echo") == 0)
    {
        handle_redirection(shell);  // Ensure redirection is handled before echo
        handle_echo(shell); // Handle the echo itself
    }
    else
    {
        // Handle redirection before execution for non-builtin commands
        handle_redirection(shell);

        pid_t pid = fork();
        if (pid == 0)
        {
            // Execute command
            execvp(shell->args[0], shell->args);
            perror("minishell");
            exit(127);
        }
        else
            waitpid(pid, NULL, 0);
    }
}

