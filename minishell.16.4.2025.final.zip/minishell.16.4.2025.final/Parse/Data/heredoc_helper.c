/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   heredoc_helper.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thitran <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/20 09:11:05 by thitran           #+#    #+#             */
/*   Updated: 2025/04/03 10:11:18 by thitran          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "../../Header/Parsing.h"
#include "../../libft/libft.h"

char	*pushcontent_clean(int heredoc, char *readed_data)
{
	write(heredoc, readed_data, ft_strlen(readed_data));
	write(heredoc, "\n", 1);
	free(readed_data);
	return (NULL);
}

void	free_elem(char *eof, char *index)
{
	free(eof);
	free(index);
}

void	here_signal(int heredoc)
{
	if (heredoc == SIGINT)
	{
		status_setter(1, 1);
		if (dup2(STDERR_FILENO, 0) == -1)
			error_announcer(strerror(errno), 0);
		write(1, "\n", 1);
		close(STDIN_FILENO);
	}
}

int	manage_heredoc(t_cmd **head, t_my_env **env)
{
	t_cmd	*curs;
	int		i;

	i = 1;
	curs = (*head);
	while (curs)
	{
		if (curs->file == HEREDOC_LIM)
		{
			curs->content = here_doc_(curs->content, \
				curs->state, env, ft_itoa(i));
			if (!(ttyname(STDIN_FILENO)))
				return (1337);
			i++;
		}
		curs = curs->next;
	}
	return (1);
}

void	close_oldout(int fd)
{
	if (fd != 1)
		close(fd);
}
