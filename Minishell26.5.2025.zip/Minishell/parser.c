/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parser.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thitran <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/20 09:09:34 by thitran           #+#    #+#             */
/*   Updated: 2025/03/20 09:09:55 by thitran          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "libft/libft.h"
#include "minishell.h"
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

void expand_variables(t_shell *shell)
{
    for (int i = 0; shell->args[i]; i++)
    {
        if (shell->args[i][0] == '$') // Check for variable prefix
        {
            char *var_name = shell->args[i] + 1; // Skip '$'
            char *value = NULL;

            if (var_name[0] == '?' && var_name[1] == '\0') // Special case for $?
            {
                // Allocate enough memory for the exit status (max 10 digits + null terminator)
                value = malloc(12);
                if (value)
                {
                    int temp = shell->last_exit_status;
                    int index = 0;

                    // Convert integer to string manually
                    if (temp == 0)
                    {
                        value[index++] = '0';
                    }
                    else
                    {
                        char buffer[12];
                        int buf_index = 0;

                        while (temp > 0)
                        {
                            buffer[buf_index++] = '0' + (temp % 10);
                            temp /= 10;
                        }

                        // Reverse the buffer into value
                        while (buf_index > 0)
                        {
                            value[index++] = buffer[--buf_index];
                        }
                    }
                    value[index] = '\0'; // Null-terminate the string
                }
            }
            else
            {
                value = getenv(var_name); // Get environment variable value
                if (value)
                    value = ft_strdup(value); // Duplicate to avoid modifying read-only memory
            }

            if (value)
            {
                free(shell->args[i]);   // Free old memory
                shell->args[i] = value; // Replace with expanded value
            }
        }
    }
}

void parse_input(t_shell *shell)
{
    int i = 0, j = 0, k = 0;
    char **args;
    char *input = shell->input;

    // Allocate space for 100 arguments (this can be resized if needed)
    args = malloc(sizeof(char *) * 100);  
    if (!args)
    {
        perror("malloc");
        return;
    }

    while (input[i])
    {
        while (input[i] == ' ') // Skip spaces
            i++;

        if (!input[i]) // End of input
            break;

        // Dynamically allocate space for each argument (adjust buffer size if needed)
        args[j] = malloc(sizeof(char) * 256); 
        if (!args[j])
        {
            perror("malloc");
            // Free previously allocated memory before returning
            for (int l = 0; l < j; l++) 
                free(args[l]);
            free(args);
            return;
        }

        k = 0;
        while (input[i] && input[i] != ' ') // Copy argument until space
            args[j][k++] = input[i++];

        args[j][k] = '\0'; // Null-terminate argument
        j++;
    }

    args[j] = NULL; // Null-terminate argument list

    // Set the arguments in the shell structure
    shell->args = args;

    // Optionally expand variables (if necessary)
    expand_variables(shell);
}




