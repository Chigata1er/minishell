/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parser.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thitran <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/20 09:09:34 by thitran           #+#    #+#             */
/*   Updated: 2025/03/28 10:47:34 by thitran          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "libft/libft.h"
#include "minishell.h"
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#define MAX_WORDS 100
#define MAX_WORD_LEN 256

void expand_variables(t_shell *shell)
{
    for (int i = 0; shell->args[i]; i++)
    {
        if (shell->args[i][0] == '$') // Check for variable prefix
        {
            char *var_name = shell->args[i] + 1; // Skip '$'
            char *value = NULL;

            if (var_name[0] == '?' && var_name[1] == '\0') // Special case for $?
            {
                // Allocate enough memory for the exit status (max 10 digits + null terminator)
                value = malloc(12);
                if (value)
                {
                    int temp = shell->last_exit_status;
                    int index = 0;

                    // Convert integer to string manually
                    if (temp == 0)
                    {
                        value[index++] = '0';
                    }
                    else
                    {
                        char buffer[12];
                        int buf_index = 0;

                        while (temp > 0)
                        {
                            buffer[buf_index++] = '0' + (temp % 10);
                            temp /= 10;
                        }

                        // Reverse the buffer into value
                        while (buf_index > 0)
                        {
                            value[index++] = buffer[--buf_index];
                        }
                    }
                    value[index] = '\0'; // Null-terminate the string
                }
            }
            else
            {
                value = getenv(var_name); // Get environment variable value
                if (value)
                    value = ft_strdup(value); // Duplicate to avoid modifying read-only memory
            }

            if (value)
            {
                free(shell->args[i]);   // Free old memory
                shell->args[i] = value; // Replace with expanded value
            }
        }
    }
}

void	free_args(char **args, int count)
{
	while (count--)
		free(args[count]);
	free(args);
}

char	**allocate_args(void)
{
	char	**args;

	args = malloc(sizeof(char *) * MAX_WORDS);
	if (!args)
		perror("malloc");
	return (args);
}

char	*extract_word(char *input, int *i)
{
	char	*word;
	int		k;

	word = malloc(sizeof(char) * MAX_WORD_LEN);
	k = 0;
	if (!word)
	{
		perror("malloc");
		return (NULL);
	}
	while (input[*i] && input[*i] != ' ')
		word[k++] = input[(*i)++];
	word[k] = '\0';
	return (word);
}

void	process_input(char *input, char **args, int *j)
{
	int	i;

	i = 0;
	while (input[i])
	{
		while (input[i] == ' ')
			i++;
		if (!input[i])
			break ;
		args[*j] = extract_word(input, &i);
		if (!args[*j])
		{
			free_args(args, *j);
			return ;
		}
		(*j)++;
	}
	args[*j] = NULL;
}

void	parse_input(t_shell *shell)
{
	int		j;
	char	**args;

	j = 0;
	if (!shell->input)
	{
		perror("Input is NULL");
		return ;
	}
	args = allocate_args();
	if (!args)
	{
		shell->args = NULL;
		return ;
	}
	process_input(shell->input, args, &j);
	shell->args = args;
	expand_variables(shell);
}
