/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thitran <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/28 09:49:50 by thitran           #+#    #+#             */
/*   Updated: 2025/03/28 09:57:58 by thitran          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stddef.h>
#include <stdlib.h>

char	*ft_strndup(const char *src, size_t n)
{
	size_t	len;
	size_t	i;
	char	*dup;

	len = 0;
	while (len < n && src[len])
		len++;
	dup = malloc(len + 1);
	if (!dup)
		return (NULL);
	i = 0;
	while (src[i] != '\0' && i < len)
	{
		dup[i] = src[i];
		i++;
	}
	dup[len] = '\0';
	return (dup);
}

char	*ft_strcpy(char *dest, char *src)
{
	int	i;

	i = 0;
	while (src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

int	ft_isspace(char c)
{
	return (c == ' ' || c == '\t' || c == '\n' || c == '\v'
		|| c == '\f' || c == '\r');
}

size_t	ft_strcspn(const char *str, const char *reject)
{
	size_t		i;
	const char	*r;

	i = 0;
	while (str[i] != '\0')
	{
		r = reject;
		while (*r != '\0')
		{
			if (str[i] == *r)
			{
				return (i);
			}
			r++;
		}
		i++;
	}
	return (i);
}
