/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pwd.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thitran <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/20 09:11:05 by thitran           #+#    #+#             */
/*   Updated: 2025/04/03 10:03:47 by thitran          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "../Header/Parsing.h"
#include "../libft/libft.h"

int	run_pwd(char **cmd_table)
{
	char	*working_dir;

	(void)cmd_table;
	working_dir = getcwd(NULL, PATH_MAX);
	if (!working_dir)
	{
		error_announcer(strerror(errno), 0);
		return (EXIT_FAILURE);
	}
	write(1, working_dir, ft_strlen(working_dir));
	write(1, "\n", 1);
	free(working_dir);
	return (SUCCES_PROC);
}
